# SHADOW MAZE — Horror Game
## Projeto Android (WebView App)

### Como gerar o APK:

#### Opção 1 — Android Studio (Recomendado)
1. Instale o Android Studio: https://developer.android.com/studio
2. Abra este projeto no Android Studio (File > Open > selecione esta pasta)
3. Aguarde o Gradle sincronizar
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s)
5. O APK estará em: `app/build/outputs/apk/debug/app-debug.apk`

#### Opção 2 — Linha de comando (Linux/Mac)
```bash
# Instale Java JDK 17+ e Android SDK
export ANDROID_HOME=~/Android/Sdk
chmod +x ./gradlew
./gradlew assembleDebug
# APK gerado em: app/build/outputs/apk/debug/app-debug.apk
```

#### Opção 3 — Online (mais fácil)
1. Acesse: https://www.pwabuilder.com
2. Ou use: https://gonative.io
3. Faça upload do arquivo `ShadowMaze_Horror.html`
4. Baixe o APK gerado

### Instalar no Android (sideload):
1. No celular: Configurações > Segurança > Fontes desconhecidas (ativar)
2. Transfira o .apk para o celular
3. Abra o arquivo e instale

### Estrutura do projeto:
```
ShadowMaze/
├── app/
│   ├── src/main/
│   │   ├── assets/
│   │   │   └── index.html     ← O JOGO COMPLETO
│   │   ├── java/com/shadowmaze/horror/
│   │   │   └── MainActivity.java
│   │   ├── res/values/
│   │   │   └── styles.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── gradle/wrapper/
│   └── gradle-wrapper.properties
├── build.gradle
└── settings.gradle
```

### Controles no celular:
O jogo usa teclado. Para jogar no celular recomendamos:
- Conectar um gamepad Bluetooth
- Usar teclado físico Bluetooth
- Ou adaptar o HTML para adicionar botões touch (ver comentário no index.html)

### Specs do app:
- minSdk: 21 (Android 5.0+)
- targetSdk: 34 (Android 14)
- Orientação: Landscape
- Fullscreen: Sim
- WebView com JavaScript habilitado
